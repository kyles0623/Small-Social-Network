


<form method="post" action="index.php?page=friend&function=search" >
	<label for="search">Search: </label>
	<input type="text" name="search" id="search" />

</form>

<section id="friends">
Search for your friends and add them!

</section>

<script type="text/javascript" src="<?php echo BASE_URL; ?>js/search.js" ></script>
